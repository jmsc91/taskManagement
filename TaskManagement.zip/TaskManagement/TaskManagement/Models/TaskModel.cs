﻿namespace TaskManagement.Models
{
    public class TaskModel
    {
        public int Id { get; set; }
        public string TaskName { get; set; }
        public string TaskDescription { get; set; }
        public bool TaskComplete { get; set; } 

    }
}
