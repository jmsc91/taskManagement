﻿using Microsoft.AspNetCore.Mvc;
using TaskManagement.Models;
using TaskManagement.Controllers;
using System.IO;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TaskManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class APIController : ControllerBase
    {
        [HttpGet("GetAllTasks")]
        public IActionResult GetAllTasks()
        {
            //get data from a file
            string filePath = @"tasks.txt";
            if (System.IO.File.Exists(filePath))
            {
                var lines = System.IO.File.ReadAllLines(filePath);
                var tasks = new List<TaskModel>();

                if(lines.Length <= 0)
                {
                    return NotFound("There is no task in the file");
                }

                //assign to taskModel
                foreach (var line in lines)
                {
                    var element = line.Split(',');
                    //check if got 4 elements in the line,
                    if (element.Length - 1 == 4 && int.TryParse(element[0], out int id) && bool.TryParse(element[3], out bool isComplete))
                    {
                        tasks.Add(new TaskModel
                        {
                            Id = id,
                            TaskName = element[1],
                            TaskDescription = element[2],
                            TaskComplete = isComplete
                        });
                    }
                }

                return Ok(tasks);
            }
            else
            {
                return NotFound("File not found");
            }
        }

        [HttpPost("UpdateTask/{taskId}")]
        public IActionResult UpdateTask(int taskId)
        {
            try
            {
                string filePath = @"tasks.txt";
                if (System.IO.File.Exists(filePath))
                {
                    var lines = System.IO.File.ReadAllLines(filePath);
                    var tasks = new List<TaskModel>();

                    if (lines.Length <= 0)
                    {
                        return NotFound("There is no task in the file");
                    }

                    //assign to taskModel
                    foreach (var line in lines)
                    {
                        var element = line.Split(',');
                        //check if got 4 elements in the line,
                        if (element.Length - 1 == 4 && int.TryParse(element[0], out int id) && bool.TryParse(element[3], out bool isComplete))
                        {
                            tasks.Add(new TaskModel
                            {
                                Id = id,
                                TaskName = element[1],
                                TaskDescription = element[2],
                                TaskComplete = isComplete
                            });
                        }
                    }

                    var task = tasks.FirstOrDefault(x => x.Id == taskId);
                    if (task != null && !task.TaskComplete)
                    {
                        task.TaskComplete = true;
                    }

                    tasks.Remove(task); //delete existing record
                    tasks.Add(task); //add new updated record
                                     //sort the order
                    tasks = tasks.OrderBy(x => x.Id).ToList();

                    //save to file
                    var newlines = tasks.Select(x => $"{x.Id},{x.TaskName},{x.TaskDescription},{x.TaskComplete},");
                    System.IO.File.WriteAllLines(filePath, newlines);

                    return Ok(task);

                }
                else
                {
                    return NotFound("File not found");
                }
            }
            catch(Exception ex)
            {
                return Ok(ex);
            }
        }

        [HttpPost("AddTask")]
        public IActionResult AddTask([FromBody] TaskModel task)
        {
            try
            {
                string filePath = @"tasks.txt";
                if (System.IO.File.Exists(filePath))
                {
                    var lines = System.IO.File.ReadAllLines(filePath);
                    var tasks = new List<TaskModel>();

                    if(lines.Length > 0)
                    {
                        //assign to taskModel
                        foreach (var line in lines)
                        {
                            var element = line.Split(',');
                            //check if got 4 elements in the line,
                            if (element.Length - 1 == 4 && int.TryParse(element[0], out int id) && bool.TryParse(element[3], out bool isComplete))
                            {
                                tasks.Add(new TaskModel
                                {
                                    Id = id,
                                    TaskName = element[1],
                                    TaskDescription = element[2],
                                    TaskComplete = isComplete
                                });
                            }
                        }
                    }

                    //take the max number + 1 for the new id
                    task.Id = tasks.Any() ? tasks.Max(t => t.Id) + 1 : 1;

                    tasks.Add(task); //add new updated record
                                     //sort the order
                    tasks = tasks.OrderBy(x => x.Id).ToList();

                    //save to file
                    var newlines = tasks.Select(x => $"{x.Id},{x.TaskName},{x.TaskDescription},{x.TaskComplete},");
                    System.IO.File.WriteAllLines(filePath, newlines);

                    return Ok(task);

                }
                else
                {
                    return NotFound("File not found");
                }
            }
            catch (Exception ex)
            {
                return Ok(ex);
            }
        }

    }
}
